import React, { useState, useEffect } from 'react';
import './Login.css';

const formStyle = {
    maxWidth: '400px',
    width: '100%',
    margin: '20px auto 0'
}

const inputStyle = {
    borderRadius: 10,
    padding: '10px 20px',
    border: '1px solid #333',
    outline: 'none',
    width: '100%',
    boxSizing: 'border-box',
    fontSize: '1em'
}

const buttonStyle = {
    backgroundColor: '#333',
}

const buttonStyleHover = {
    backgroundColor: '#111',
}

const labelStyle = {
    display: 'block',
    textAlign: 'left',
}

function Login(){
    const [btnHover, setBtnHover] = useState(false);
    const [email, setEmail] = useState("tiagoluizrs@gmail.com");
    const [password, setPassword] = useState("123456");
    const [message, setMessage] = useState("")

    const toggleBtnHover = () => {
        setBtnHover(!btnHover);
    } 

    const handleChange = (event, setState) => {
        const palavrasFeias = ['Pênis', 'Cacete'];

        if(palavrasFeias.includes(event.target.value)){
            setState("");
            setMessage("Palavras chulas não são permitidas")
        }else{
            setState(event.target.value);
            setMessage("")
        }
    }

    const enviar = (event) => {
        event.preventDefault();
        console.log(email)
        console.log(password)
    }

    return <form style={formStyle} onSubmit={enviar}>
        <div>
            <label 
                htmlFor="email"
                style={labelStyle}>E-mail:</label>
            <input 
                type="email" 
                id="email"
                value={email}
                onChange={function(event){
                    handleChange(event, setEmail)
                }}
                style={inputStyle}/>
        </div>
        <div>
            <label 
                htmlFor="password"
                style={labelStyle}>Password:</label>
            <input 
                type="password" 
                id="password"
                value={password}
                onChange={(event) => handleChange(event, setPassword)}
                style={inputStyle}/>
        </div>
        <button 
            onMouseOver={toggleBtnHover}
            onMouseOut={toggleBtnHover}
            type="submit" 
            style={btnHover ? buttonStyleHover : buttonStyle}>Entrar</button>
        <small>{message}</small>
    </form>
}

export default Login;