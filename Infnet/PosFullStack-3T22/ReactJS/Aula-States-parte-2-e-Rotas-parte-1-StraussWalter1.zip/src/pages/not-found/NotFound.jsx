import React from 'react';

const NotFound = () => {
    return <h1>Página não encontrada</h1>
}

export default NotFound;