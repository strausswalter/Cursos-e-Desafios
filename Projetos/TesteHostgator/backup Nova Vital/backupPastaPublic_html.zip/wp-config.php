<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'vitalt22_wp956' );

/** MySQL database username */
define( 'DB_USER', 'vitalt22_wp956' );

/** MySQL database password */
define( 'DB_PASSWORD', '(g379SpMy]' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'sf8n3d3x2g5enyvtisnjk6v3yijsf7ejjhhruax6byhsy3vuehckptkfzmr31dku' );
define( 'SECURE_AUTH_KEY',  'vxcfu6imo98ljgtqdsggvuysnmho0sf8vvptvqzqg0fkglb6tkh2iwvapmsmv7b7' );
define( 'LOGGED_IN_KEY',    'j4f1jktek0iofm1tp7vz1qnmax1ozhohebbdpnjy6mgvic16kt7xu83bdvvy4eee' );
define( 'NONCE_KEY',        '7tjhuhjz3qha2uxyrjw5cwg28vowqhb352b7rk8rpwa0c1ndmsibrtrk7rtdhnii' );
define( 'AUTH_SALT',        'bxvqp7msfmx1zlxkxcof7uigtzjen9xs3lx38sdcimvhisnqev6iuco0ypww6yjt' );
define( 'SECURE_AUTH_SALT', 'ekamtryxhlyjkbtconnv4fvpacidaayiurisnzqxnmdzrwcuydhznvioplf7ur3k' );
define( 'LOGGED_IN_SALT',   '0ryl5wdndhxmcwesmlmmoqkhtv6idgtgvbia0uyhl6vivyjqttqdlwoeoa1k45ie' );
define( 'NONCE_SALT',       'okzjxf1zufy1st899byp2lbiyrrigxjxacyfdj8e8oikxy97hm6kf5dglzug7dfk' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpww_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
